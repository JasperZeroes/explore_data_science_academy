# mypackage
This library was created as an example of how to publish your own python package

## Building this package locally

    'python setup.py sdist'

## Installing this package from Github
    'pip install git+https://github.com/JasperZeroes/explore_data_science_academy/python/mypackage.git'

## Updating this package from Github
    'pip install --upgrade git+https://github.com/JasperZeroes/explore_data_science_academy/python/mypackage.git'
